package model;

public class GestoreLogin {
}
