function myFunction() {
    alert("Il Prodotto è stato aggiunto al carrello. Cliccare OK per Continuare.");
}