function myFunction() {
    alert("Le modifiche sono state effettuate con successo. Cliccare OK per Continuare.");
}