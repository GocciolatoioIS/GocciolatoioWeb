package model;

import model.ConPool;
import model.Ordine;
import model.Prodotto;
import model.Utente;

import java.sql.*;
import java.util.ArrayList;

public class OrdineDAO {
    public void doSave(Ordine o) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO ordine (id_utente) VALUES(?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1,o.getId_utente());
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }
            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            int id = rs.getInt(1);
            o.setId(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Ordine> retriveAll() {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, id_utente FROM ordine");
            ArrayList<Ordine> list = new ArrayList<>();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Ordine o = new Ordine();
                o.setId(rs.getInt(1));
                o.setId_utente(rs.getInt(2));
                list.add(o);
            }

            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Ordine> retriveByIdUser(int id){
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, id_utente FROM ordine WHERE id_utente=?");
            ps.setInt(1,id);
            ArrayList<Ordine> list = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            Ordine o = new Ordine();
            while (rs.next()) {
                o.setId(rs.getInt(1));
                o.setId_utente(rs.getInt(2));
                list.add(o);
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteOrder(int id) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("DELETE FROM ordine WHERE id=?");
            ps.setInt(1,id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
