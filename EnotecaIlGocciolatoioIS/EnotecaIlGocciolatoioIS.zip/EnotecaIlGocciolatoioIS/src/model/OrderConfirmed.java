package model;

import java.util.Date;

public class OrderConfirmed 
{
	private String orderId;
	private double orderCost;
	private Date dateOfPayment;
	
	public String getOrderId()
	{
		return orderId;
	}
	
	public void setOrderId(String orderId)
	{
		this.orderId = orderId;
	}
	
	public double getOrderCost()
	{
		return orderCost;
	}
	
	public void setOrderCost(double orderCost)
	{
		this.orderCost = orderCost;
	}
	
	public Date getDateOfPayment()
	{
		return dateOfPayment;
	}
	
	public void setDateOfPayment(Date dateOfPayment)
	{
		this.dateOfPayment = dateOfPayment;
	}
}
