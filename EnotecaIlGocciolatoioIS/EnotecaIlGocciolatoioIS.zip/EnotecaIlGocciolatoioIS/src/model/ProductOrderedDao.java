package model;

import model.ConPool;
import model.Ordine;
import model.Prodotto;
import model.ProductOrdered;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class ProductOrderedDao {

	/*public List<ProductOrdered> retrieveById(int order) throws SQLException {

		Connection conn = ConPool.getConnection();

		PreparedStatement stmt2 = conn.prepareStatement

				("Select  nome,quantita,prodotto.nome,ordine.id from productordered,prodotto,ordine where ordine.id= ? and productordered.nome=prodotto.nome");

		stmt2.setInt(1, order);

		ResultSet set = stmt2.executeQuery();

		List<ProductOrdered> list = new ArrayList<ProductOrdered>();
		while (set.next()) {

			ProductOrdered ord = new ProductOrdered();
			ord.setOrderId(order);
			ord.setName(set.getString("nome"));
			ord.setQuantity(set.getInt("quantity"));
			ord.setName(set.getString("prdotto.nome"));

			list.add(ord);
		}

		return list;
	} */

	public ArrayList<ProductOrdered> retriveByOrderId(int id){
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps =
					con.prepareStatement("SELECT product_id, nome, quantita, order_id FROM productordered WHERE order_id=? ");
			ps.setInt(1,id);
			ArrayList<ProductOrdered> list = new ArrayList<>();
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				ProductOrdered po= new ProductOrdered();
				po.setProductId(rs.getInt(1));
				po.setName(rs.getString(2));
				po.setQuantity(rs.getInt(3));
				po.setOrderId(rs.getInt(4));
				list.add(po);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void doSave(ProductOrdered po) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"INSERT INTO productordered (nome,quantita,order_id,product_id) VALUES(?,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);
			ps.setString(1,po.getName());
			ps.setInt(2,po.getQuantity());
			ps.setInt(3,po.getOrderId());
			ps.setInt(4,po.getProductId());
			if (ps.executeUpdate() != 1) {
				throw new RuntimeException("INSERT error.");
			}
			ResultSet rs = ps.getGeneratedKeys();
			rs.next();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
