package model;

import model.ConPool;
import model.Prodotto;
import model.Utente;

import java.sql.*;
import java.util.ArrayList;

public class UtenteDAO {
    public ArrayList<Utente> retriveAll() {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, email, username, ruolo, citta, cap, via, ncivico FROM utente");
            ArrayList<Utente> list = new ArrayList<>();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Utente u = new Utente();
                u.setId(rs.getInt(1));
                u.setEmail(rs.getString(2));
                u.setUsername(rs.getString(3));
                u.setRuolo(rs.getString(4));
                u.setCitta(rs.getString(5));
                u.setCap(rs.getInt(6));
                u.setVia(rs.getString(7));
                u.setNcivico(rs.getInt(8));
                list.add(u);
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<String> retriveUser() {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT username FROM utente ");

            ResultSet rs = ps.executeQuery();

            ArrayList<String> list = new ArrayList<>();

            while (rs.next()) {
                String e = rs.getString(1);
                list.add(e);
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Utente doRetrieveByUsernamePassword(String username, String password) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "SELECT id, username, pass, email, ruolo, citta, cap, via, ncivico FROM utente WHERE username=? AND pass=SHA1(?)");
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Utente p = new Utente();
                p.setId(rs.getInt(1));
                p.setUsername(rs.getString(2));
                p.setPass(rs.getString(3));
                p.setEmail(rs.getString(4));
                p.setRuolo(rs.getString(5));
                p.setCitta(rs.getString(6));
                p.setCap(rs.getInt(7));
                p.setVia(rs.getString(8));
                p.setNcivico(rs.getInt(9));

                return p;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Utente doRetrieveByUsernameEmail(String username, String email) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "SELECT id, username, email FROM utente WHERE username=? AND email=?");
            ps.setString(1, username);
            ps.setString(2, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Utente p = new Utente();
                p.setId(rs.getInt(1));
                p.setUsername(rs.getString(2));
                p.setEmail(rs.getString(3));


                return p;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doSave(Utente user) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO utente (email, username, pass, ruolo) VALUES(?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getEmail());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPass());
            ps.setString(4, user.getRuolo());
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }
            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            int id = rs.getInt(1);
            user.setId(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public void doUpdate(Utente u) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("UPDATE utente SET username=?, email=?, citta=?, cap=?, via=?, ncivico=?, ruolo=? WHERE id=?");

            ps.setString(1,u.getUsername());
            ps.setString(2,u.getEmail());
            ps.setString(3, u.getCitta());
            ps.setInt(4, u.getCap());
            ps.setString(5, u.getVia());
            ps.setInt(6, u.getNcivico());
            ps.setString(7,u.getRuolo());
            ps.setInt(8, u.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doUpdatePass(Utente u) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("UPDATE utente SET pass=? WHERE id=?");

            ps.setString(1,u.getPass());
            ps.setInt(2, u.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteUser(int id) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("DELETE FROM utente WHERE id=?");
            ps.setInt(1,id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Utente retriveById(int n){
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, email, username, pass, ruolo, citta, cap, via, ncivico FROM utente WHERE id=?");
            ps.setInt(1,n);
            ResultSet rs = ps.executeQuery();
            Utente u = new Utente();
            if (rs.next()) {
                u.setId(rs.getInt(1));
                u.setEmail(rs.getString(2));
                u.setUsername(rs.getString(3));
                u.setPass(rs.getString(4));
                u.setRuolo(rs.getString(5));
                u.setCitta(rs.getString(6));
                u.setCap(rs.getInt(7));
                u.setVia(rs.getString(8));
                u.setNcivico(rs.getInt(9));
            }
            return u;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }



}
