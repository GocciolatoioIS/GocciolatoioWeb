package control;

import model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;

/*
    Questa Servlet è utilizzata per l'acquisto dei prodotti.
    Viene reindirizzata alla fine col pulsante di acquisto
 */
@WebServlet("/acquisto")
public class AcquistoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Utente user= (Utente) request.getSession().getAttribute("utente");
        Carrello cart = (Carrello) request.getSession().getAttribute("carrello");

        ProductOrderedDao podao=new ProductOrderedDao();
        OrdineDAO ordao=new OrdineDAO();
        ProdottoDAO prodao=new ProdottoDAO();

        //Controllo per verificare se l'utente è loggato, oppure se ha inserito un proprio indirizzo
        if (user == null ) {
            response.sendRedirect("LoginRegistrazione.jsp");
            return;
        }
        if(user.getVia()==null){
            response.sendRedirect("AggiungiIndirizzo.jsp");
            return;
        }

        //Creo l'ordine
        Collection<Carrello.ProdottoQuantita> lista=cart.getProdotti();
        Ordine ord=new Ordine();

        ord.setId_utente(user.getId());
        ordao.doSave(ord);//Salvo l'ordine nel DB

        //Ora mi creo una istanza del prodotto ordinato
        for(Carrello.ProdottoQuantita p:lista){
            ProductOrdered po=new ProductOrdered();
            po.setProductId(p.getProdotto().getId());
            po.setOrderId(ord.getId());
            po.setName(p.getProdotto().getNome());
            po.setQuantity(p.getQuantita());

            podao.doSave(po); //Qui salvi il prodotto ordinato

            prodao.doUpdateQuantity(p.getProdotto().getId(),p.getQuantita()); //Aggiorni le quantità acquistate con le quantità nel magazzino
        }

        //E reindirizzo una pagina statica
        request.getSession().removeAttribute("carrello");
        String address = "/Grazie.jsp";
        RequestDispatcher dispatcher =
                request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}
