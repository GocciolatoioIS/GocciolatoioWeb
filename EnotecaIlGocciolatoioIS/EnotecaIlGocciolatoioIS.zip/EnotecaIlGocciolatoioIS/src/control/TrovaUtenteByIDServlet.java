package control;

import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

    @WebServlet("/finduser")
    public class TrovaUtenteByIDServlet extends HttpServlet {
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            String param=request.getParameter("id");
            int id=Integer.parseInt(param);

            UtenteDAO udao=new UtenteDAO();
            Utente u=udao.retriveById(id);
            request.setAttribute("user1",u);
            String address="/ModificaUtenteByAdmin.jsp";
            RequestDispatcher dispatcher =
                    request.getRequestDispatcher(address);
            dispatcher.forward(request, response);
        }
    }

