package control;

import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/register")
public class Registrazione extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String username=request.getParameter("username");
        String email=request.getParameter("email");
        String pass=request.getParameter("pass");

        String regUsername =  "/^[0-9A-Za-z]+$/";
        String regPassword =  "/^[A-Za-z]+$/";
        Boolean validate=true;

        if(!request.getParameter("username").matches(regUsername)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("pass").matches(regPassword)) {
            System.out.println("password dato corretto");
        }else {validate=false;}

        if(validate==true) {
            System.out.println("tutti i campi sono giusti");
        } else {
            RequestDispatcher view = request.getRequestDispatcher("LoginRegistrazione.jsp");/*dove inoltro il form*/
            HttpSession currentSession = request.getSession();
            currentSession.setAttribute("error", "error");
            view.forward(request,response);
            return;
        }
        //Se tutti i controlli sono stati superati si crea il bean e si inserisce nel database

        UtenteDAO utenteDAO=new UtenteDAO();
        ArrayList<String> users=utenteDAO.retriveUser();
        String address;

        //Controllo se l'utente è già inserito nel db
        for(String e:users){
            if(e.equals(username)){
                String p="nada";
                request.setAttribute("err",p);
                address="/LoginRegistrazione.jsp";
                RequestDispatcher dispatcher =
                        request.getRequestDispatcher(address);
                dispatcher.forward(request, response);
            }
        }

        //Viene registrato nel db
        Utente u=new Utente();
        u.setEmail(email);
        u.setUsername(username);
        u.setPass(pass);
        u.setRuolo("utente");

        utenteDAO.doSave(u);
        request.getSession().setAttribute("utente", u);

        address = "/index.html";
        RequestDispatcher dispatcher =
                request.getRequestDispatcher(address);
        dispatcher.forward(request, response);

    }
}
