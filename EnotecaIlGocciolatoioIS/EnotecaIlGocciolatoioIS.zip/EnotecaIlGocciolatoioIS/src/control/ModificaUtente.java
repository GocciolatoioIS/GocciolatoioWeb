package control;

import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/modifyuser")
public class ModificaUtente extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Utente user= (Utente) request.getSession().getAttribute("utente");
        int id = user.getId();

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("pass");
        String citta = request.getParameter("citta");
        String cap = request.getParameter("cap");
        String via = request.getParameter("via");
        String ncivico = request.getParameter("ncivico");
        String ruolo=request.getParameter("ruolo");

        String regUsername =  "/^[0-9A-Za-z]+$/";
        String regString =  "/^[A-Za-z]+$/";
        String regNum =  "/^[0-9]+$/";
        String regPassword =  "/^[A-Za-z]+$/";
        Boolean validate=true;

        if(!request.getParameter("username").matches(regUsername)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("citta").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("cap").matches(regNum)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("via").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("ncivico").matches(regUsername)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("ruolo").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("pass").matches(regPassword)) {
            System.out.println("password dato corretto");
        }else {validate=false;}

        if(validate==true) {
            System.out.println("tutti i campi sono giusti");
        } else {
            RequestDispatcher view = request.getRequestDispatcher("ModificaUtente.jsp");/*dove inoltro il form*/
            HttpSession currentSession = request.getSession();
            currentSession.setAttribute("error", "error");
            view.forward(request,response);
            return;
        }

        Utente u=new Utente();
        u.setId(id);
        u.setEmail(email);
        u.setUsername(username);
        u.setPass(password);
        u.setCitta(citta);
        u.setCap(Integer.parseInt(cap));
        u.setVia(via);
        u.setNcivico(Integer.parseInt(ncivico));
        u.setRuolo(ruolo);

        UtenteDAO userDao=new UtenteDAO();
        userDao.doUpdate(u);

        request.getSession().setAttribute("utente", u);

        if(u.getRuolo().equals("utente")){
            String address = "/InformazioniPersonali.jsp";
            RequestDispatcher dispatcher =
                    request.getRequestDispatcher(address);
            dispatcher.forward(request, response);
        }

        String address = "/ProfiloAmministratore.jsp";
        RequestDispatcher dispatcher =
                  request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}
