package control;

import model.Prodotto;
import model.ProdottoDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.http.Part;
import java.io.IOException;

/*
    Serve per aggiungere prodotti al DB
 */
@WebServlet("/add-product")
public class AggiungiProdotto extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Settaggio di vari parametri tramite request.
        String nome = request.getParameter("nome");
        String descrizione = request.getParameter("descrizione");
        String tipo = request.getParameter("tipo");
        String prezzo = request.getParameter("prezzo");
        Double pre=Double.parseDouble(prezzo);
        String sconto = request.getParameter("sconto");
        Double sc=Double.parseDouble(sconto);
        Part immagine = request.getPart("foto");
        String annata = request.getParameter("anno");
        int anno=Integer.parseInt(annata);
        String regione = request.getParameter("regione");
        String gradazione=request.getParameter("gradazione");
        int grad=Integer.parseInt(gradazione);
        String formato=request.getParameter("formato");
        int forma=Integer.parseInt(formato);
        String quantita_magazino=request.getParameter("quantita_magazzino");
        int qnt=Integer.parseInt(quantita_magazino);
        String nome_categoria = request.getParameter("nome_categoria");

        String regString =  "/^[A-Za-z]+$/";
        String regNum =  "/^[0-9]+$/";
        Boolean validate=true;

        if(!request.getParameter("nome").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("descrizione").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("anno").matches(regNum)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("regione").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("gradazione").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("formato").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("quantita_magazzino").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("prezzo").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("sconto").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }

        if(validate==true) {
            System.out.println("tutti i campi sono giusti");
        } else {
            RequestDispatcher view = request.getRequestDispatcher("AggiungiProdotto.jsp");/*dove inoltro il form*/
            HttpSession currentSession = request.getSession();
            currentSession.setAttribute("error", "error");
            view.forward(request,response);
            return;
        }


        ProdottoDAO proDAO=new ProdottoDAO();
        Prodotto p=new Prodotto();
        p.setNome(nome);
        p.setDescrizione(descrizione);
        p.setTipo(tipo);
        p.setPrezzo(pre);
        p.setSconto(sc);
        //p.setImmagine(immagine.getInputStream().readAllBytes());
        p.setAnno(anno);
        p.setRegione(regione);
        p.setGradazione(grad);
        p.setFormato(forma);
        p.setQuantita_magazzino(qnt);
        p.setNome_categoria(nome_categoria);
        proDAO.doSave(p);//Viene richiamato il metodo doSave per rendere i dati persistenti.

        String address = "/index.html";
        RequestDispatcher dispatcher =
                request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}
