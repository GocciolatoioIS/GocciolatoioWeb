package control;

import model.Prodotto;
import model.ProdottoDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/modifyproduct")
public class ModificaProdotto extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String nome=request.getParameter("nome");
        String descrizione=request.getParameter("descrizione");
        String anno=request.getParameter("anno");
        String regione=request.getParameter("regione");
        String gradazione=request.getParameter("gradazione");
        String formato=request.getParameter("formato");
        String quantita_magazzino=request.getParameter("quantita_magazzino");
        String tipo=request.getParameter("tipo");
        String prezzo=request.getParameter("prezzo");
        String sconto=request.getParameter("sconto");

        String regString =  "/^[A-Za-z]+$/";
        String regNum =  "/^[0-9]+$/";
        Boolean validate=true;

        if(!request.getParameter("nome").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("descrizione").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("anno").matches(regNum)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("regione").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("gradazione").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("formato").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("quantita_magazzino").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("prezzo").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("sconto").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }

        if(validate==true) {
            System.out.println("tutti i campi sono giusti");
        } else {
            RequestDispatcher view = request.getRequestDispatcher("ModificaProdottoByAdmin.jsp");/*dove inoltro il form*/
            HttpSession currentSession = request.getSession();
            currentSession.setAttribute("error", "error");
            view.forward(request,response);
            return;
        }

        String id = (String) request.getParameter("id");
        System.out.println(("Id prodotto: "+id));

        String nomecategoria = (String) request.getParameter("nome_categoria");
        Part foto = request.getPart("foto");

        Prodotto p=new Prodotto();
        ProdottoDAO proDao=new ProdottoDAO();

        p.setId(Integer.parseInt(id));
        p.setNome_categoria(nomecategoria);
        p.setNome(nome);
        p.setDescrizione(descrizione);
        p.setAnno(Integer.parseInt(anno));
        p.setRegione(regione);
        p.setGradazione(Integer.parseInt(gradazione));
        p.setFormato(Integer.parseInt(formato));
        p.setQuantita_magazzino(Integer.parseInt(quantita_magazzino));
        p.setTipo(tipo);
        p.setPrezzo(Double.parseDouble(prezzo));
        p.setSconto(Double.parseDouble(sconto));
        //p.setImmagine(foto.getInputStream().readAllBytes());

        proDao.doUpdate(p);

        String address = "ProfiloAmministratore.jsp";
        response.sendRedirect(address);
    }
}
