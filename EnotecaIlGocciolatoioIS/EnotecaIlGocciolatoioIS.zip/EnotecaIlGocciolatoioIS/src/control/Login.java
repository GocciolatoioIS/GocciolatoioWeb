package control;

import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")
public class Login extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final UtenteDAO utenteDAO = new UtenteDAO();

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action= request.getParameter("action");

        //Se viene cliccato su accedi
        if(action==null){
            String username= request.getParameter("username");
            String password= request.getParameter("pass");
            String address;
            Utente utente = null;
            if (username != null && password != null) {
                //Cerchiamo nel db un utente con quelle credenziali
                utente = utenteDAO.doRetrieveByUsernamePassword(username, password);
            }


            //SE l'utente non viene trovato
            if (utente == null) {
                String s="nada";
                request.setAttribute("text",s);
                address="/LoginRegistrazione.jsp";
                //response.sendRedirect(address);
                System.out.println(s);
                RequestDispatcher dispatcher =
                        request.getRequestDispatcher(address);
                dispatcher.forward(request, response);
            }

            //L'utente è stato trovato
            request.getSession().setAttribute("utente", utente);

            Cookie cookie = new Cookie("key", "value");
            cookie.setMaxAge(60);
            response.addCookie(cookie);

            //Viene rindirizzata alla HomeServlet
            address = "index.html";
            response.sendRedirect(address);
        }
        else{
            String address = "PasswordDimenticata.jsp";
            response.sendRedirect(address);
        }


    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}

