package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import model.Carrello;
import model.Carrello.ProdottoQuantita;
import model.ProdottoDAO;

/*
    Questa Servlet serve per aggiungere i prodotti al carrello
 */

@WebServlet("/carrello")
public class CarrelloServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final ProdottoDAO prodottoDAO = new ProdottoDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //Retrive del carrello dalla sessione
        HttpSession session = request.getSession();
        Carrello carrello = (Carrello) session.getAttribute("carrello");
        session.setMaxInactiveInterval(90*60); //Lo setto nella sessione per 90 minuti
        Cookie cookie = new Cookie("key", "value");
        cookie.setMaxAge(60); //60 secondi
        response.addCookie(cookie);

        if (carrello == null) {
            carrello = new Carrello();
            session.setAttribute("carrello", carrello);
        }

        //Retrive dell'id del prodotto. Successivamente possiamo richiedere due parametri:
        String prodIdStr = request.getParameter("prodId");
        if (prodIdStr != null) {
            int prodId = Integer.parseInt(prodIdStr);
            String addNumStr = request.getParameter("addNum");//Per aggiungere un valore ad uno già esistente
            if (addNumStr != null) {
                int addNum = Integer.parseInt(addNumStr);
                ProdottoQuantita prodQuant = carrello.get(prodId);
                if (prodQuant != null) {
                    prodQuant.setQuantita(prodQuant.getQuantita() + addNum); //Se il prodotto non esiste lo aggiungo
                } else {
                    carrello.put(prodottoDAO.retriveOne(prodId), addNum);//Altrimenti lo aggiorno
                }
            } else {
                String setNumStr = request.getParameter("setNum");//Questo parametro setta la quantità
                if (setNumStr != null) {
                    int setNum = Integer.parseInt(setNumStr);
                    if (setNum <= 0) {
                        carrello.remove(prodId);
                    } else {
                        ProdottoQuantita prodQuant = carrello.get(prodId);
                        if (prodQuant != null) {
                            prodQuant.setQuantita(setNum);//Il prodotto lo trova e ne aggiorna la quantità
                        } else {
                            carrello.put(prodottoDAO.retriveOne(prodId), setNum);//Se il prodotto non esiste lo aggiorna con la quantita
                        }
                    }
                }
            }
        }

        session.setAttribute("carrello", carrello);
        String address = "Carrello1.jsp";
        response.sendRedirect(address);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}


