package control;

import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/modifyuserpass")
public class ModificaPasswordServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final UtenteDAO utenteDAO = new UtenteDAO();

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username=request.getParameter("username");
        String email=request.getParameter("email");
        String pass=request.getParameter("password");

        String regUsername =  "/^[0-9A-Za-z]+$/";
        String regPassword =  "/^[A-Za-z]+$/";
        Boolean validate=true;

        if(!request.getParameter("username").matches(regUsername)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("password").matches(regPassword)) {
            System.out.println("password non corretta");
        }else{ validate=false; }
        if(validate==true) {
            System.out.println("tutti i campi sono giusti");
        } else {
            RequestDispatcher view = request.getRequestDispatcher("PasswordDimenticata.jsp");
            HttpSession currentSession = request.getSession();
            currentSession.setAttribute("error", "error");
            view.forward(request,response);
            return;
        }

        String address;

        Utente utente = null;
        if (username != null && email != null) {
            utente = utenteDAO.doRetrieveByUsernameEmail(username, email);
        }

        if (utente == null) {
            String s = "nada";
            request.setAttribute("text", s);
            address = "LoginRegistrazione.jsp";
            System.out.println(s);
            /*RequestDispatcher dispatcher =
                    request.getRequestDispatcher(address);
            dispatcher.forward(request, response);*/
            response.sendRedirect(address);
        }

        utente.setPass(pass);
        utenteDAO.doUpdatePass(utente);
        address = "LoginRegistrazione.jsp";
        response.sendRedirect(address);
    }
}