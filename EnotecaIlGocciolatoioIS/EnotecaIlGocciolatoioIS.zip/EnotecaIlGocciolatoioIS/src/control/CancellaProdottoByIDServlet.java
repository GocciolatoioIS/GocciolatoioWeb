package control;

import model.ProdottoDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteproduct")
public class CancellaProdottoByIDServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String param=request.getParameter("id");
        int id=Integer.parseInt(param);

        ProdottoDAO udao=new ProdottoDAO();
        udao.deleteProduct(id);

        String address="show-all-products";

        request.setAttribute("var","Cancellazione eseguita con Successo :)");
        response.sendRedirect(address);
    }
}