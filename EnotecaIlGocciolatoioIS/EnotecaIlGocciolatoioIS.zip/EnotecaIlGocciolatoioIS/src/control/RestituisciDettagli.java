package control;
import model.ProductOrdered;
import model.ProductOrderedDao;
import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/retrivedetails")
public class RestituisciDettagli extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ProductOrderedDao podao=new ProductOrderedDao();
        UtenteDAO userdao=new UtenteDAO();

        String idOrdineString=request.getParameter("idord");
        int ido=Integer.parseInt(idOrdineString);

        String idUserString=request.getParameter("iduser");
        int idu=Integer.parseInt(idUserString);

        Utente u=userdao.retriveById(idu);
        request.setAttribute("user2",u);

        List<ProductOrdered> lista=podao.retriveByOrderId(ido);
        request.setAttribute("lista", lista);

        String address = "/DettagliOrdine.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}