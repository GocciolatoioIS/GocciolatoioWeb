package control;

import model.Utente;
import model.UtenteDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/*
    Aggiunta dell'indirizzo dell'utente
 */
@WebServlet("/add-address")
public class AggiungiIndirizzo extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Utente user= (Utente) request.getSession().getAttribute("utente");
        if(user==null){
            response.sendRedirect("/index.html");
            return;
        }

        //Settaggio di parametri
        String citta = request.getParameter("citta");
        String cap = request.getParameter("cap");
        String via = request.getParameter("via");
        String ncivico = request.getParameter("ncivico");

        String regUsername =  "/^[0-9A-Za-z]+$/";
        String regString =  "/^[A-Za-z]+$/";
        String regNum =  "/^[0-9]+$/";
        String regPassword =  "/^[A-Za-z]+$/";
        Boolean validate=true;


        if(!request.getParameter("citta").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("cap").matches(regNum)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("via").matches(regString)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }
        if(!request.getParameter("ncivico").matches(regUsername)) {
            System.out.println("nome dato corretto");
        }else{ validate=false; }

        if(validate==true) {
            System.out.println("tutti i campi sono giusti");
        } else {
            RequestDispatcher view = request.getRequestDispatcher("AggiungiIndirizzo.jsp");/*dove inoltro il form*/
            HttpSession currentSession = request.getSession();
            currentSession.setAttribute("error", "error");
            view.forward(request,response);
            return;
        }

        user.setCitta(citta);
        user.setCap(Integer.parseInt(cap));
        user.setVia(via);
        user.setNcivico(Integer.parseInt(ncivico));

        UtenteDAO userDao=new UtenteDAO();
        userDao.doUpdate(user); //Viene richiamata il metodo doUpdate che rende i dati persistenti.

        request.getSession().setAttribute("utente", user);

        response.sendRedirect("Carrello1.jsp");
        return;
    }
}
