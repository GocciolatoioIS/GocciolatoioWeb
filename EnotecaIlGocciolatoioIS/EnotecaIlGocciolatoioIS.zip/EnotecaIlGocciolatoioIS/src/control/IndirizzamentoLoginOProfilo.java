package control;

import model.Utente;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/indirizzamento")
public class IndirizzamentoLoginOProfilo extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Cookie cookie = null;
        Cookie[] cookies = null;

        //Effettua un controllo sui cookie, se ne trova allora:
        if(cookies!=null){
            cookies = request.getCookies();
        } else {
            String address;
            HttpSession session = request.getSession();
            Utente user= (Utente) request.getSession().getAttribute("utente");
            session.setMaxInactiveInterval(60*60*24); //setta l'utente loggato per 24 Minuti

            if(user!=null){
                if(user.getRuolo().equals("utente")||user.getRuolo()==null){
                    address="/InformazioniPersonali.jsp";
                    RequestDispatcher dispatcher =request.getRequestDispatcher(address);
                    dispatcher.forward(request, response);
                }
                else
                if(user.getRuolo().equals("amministratore")){
                    address="/ProfiloAmministratore.jsp";
                    RequestDispatcher dispatcher =request.getRequestDispatcher(address);
                    dispatcher.forward(request, response);
                }

            } else {
                address = "/LoginRegistrazione.jsp";
                RequestDispatcher dispatcher =
                        request.getRequestDispatcher(address);
                dispatcher.forward(request, response);
            }
        }
    }
}
