package control;

import model.Prodotto;
import model.ProdottoDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/findproduct")
public class ModificaProdottoByAdmin extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String param=request.getParameter("id");
        int id=Integer.parseInt(param);

        ProdottoDAO udao=new ProdottoDAO();
        Prodotto p=udao.retriveOne(id);
        request.setAttribute("prodotto1",p);
        String address="/ModificaProdottoByAdmin.jsp";
        RequestDispatcher dispatcher =
                request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}