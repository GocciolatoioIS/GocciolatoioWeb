package control;

import model.Prodotto;
import model.ProdottoDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/show-product")
public class MostraProdotto extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

            //Prende il valore della stringa passata e co prendiamo l'id del nostro prodotto
            String product=request.getParameter("product");
            String address = null;

            ProdottoDAO proDAO = new ProdottoDAO();

            Prodotto p=proDAO.retriveOne(Integer.parseInt(product));
            request.setAttribute("prodotto", p);

            address = "/Prodotto.jsp";
            RequestDispatcher dispatcher = request.getRequestDispatcher(address);
            dispatcher.forward(request, response);
            response.sendRedirect(address);
             if(product==null) {

                String id=request.getParameter("prodId");
                int prodId=Integer.parseInt(id);
                p=proDAO.retriveOne(prodId);
                request.setAttribute("prodotto", p);
                address = "/Prodotto.jsp";
                dispatcher = request.getRequestDispatcher(address);
                dispatcher.forward(request, response);
             }

    }
}