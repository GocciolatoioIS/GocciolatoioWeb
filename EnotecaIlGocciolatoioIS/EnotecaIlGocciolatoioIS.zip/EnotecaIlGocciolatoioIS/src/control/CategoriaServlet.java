package control;

import model.Prodotto;
import model.ProdottoDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/show-category")
public class CategoriaServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /*
        Viene ripreso il parametro della category, e controllato a quale categoria corrisponde
         */
        String category = request.getParameter("category");
        ProdottoDAO proDAO = new ProdottoDAO();
        String address = null;
        String categoria=null;
        if (category.equals("vini")) {
            categoria = "Vino";
            request.setAttribute("category", categoria);
        }
        if (category.equals("spumanti")) {
            categoria = "Spumanti";
            request.setAttribute("category", categoria);
        }
        if (category.equals("champagne")) {
            categoria = "Champagne";
            request.setAttribute("category", categoria);
        }
        if (category.equals("birre")) {
            categoria = "Birra";
            request.setAttribute("category", categoria);
        }
        if (category.equals("superalcolici")) {
            categoria = "Superalcolici";
            request.setAttribute("category", categoria);
        }
        if (category.equals("amari")) {
            categoria = "Amari";
            request.setAttribute("category", categoria);
        }
        if (category.equals("cibo")) {
            categoria = "Cibo";
            request.setAttribute("category", categoria);
        }


        List<Prodotto> prodotti = proDAO.retriveCategory(categoria);
        request.setAttribute("prodotti", prodotti);
        address = "/Categoria.jsp"; //Dopodichè viene reindirizzata la pagina

        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}